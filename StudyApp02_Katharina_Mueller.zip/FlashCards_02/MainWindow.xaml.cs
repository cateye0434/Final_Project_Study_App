﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Data.SqlClient;


namespace FlashCards0._1
{
    public partial class MainWindow : Window
    {
        //string connectionString = Connection.GetDBConnection().ToString();
        int labelCount;
        int countNextClicks;
        int questionsAskedCount;
        double correctAnswersCount;
        string contentLbl;

        public MainWindow()
        {
            InitializeComponent();

            nextBtn.Content = "Start";
            confirmLblQuest.Content = "";
            yesRbtn.Visibility = Visibility.Hidden;
            noRbtn.Visibility = Visibility.Hidden;
            showBtn.IsEnabled = false;
            yesRbtn.IsEnabled = false;
            noRbtn.IsEnabled = false;
        }

        private async void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            //SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlConnection sqlCon = ServerConnection.GetDBConnection();
            String sql = "Insert into StudyAppItem (item_name, item_content, item_subject) values ('" + queryKeywordTB.Text + "','" + contentTB.Text + "', '" + subjectTB.Text + "')";
            SqlCommand sqlCom = new SqlCommand(sql, sqlCon);
            SqlDataAdapter adapter = new SqlDataAdapter();
            String stichwortText = queryKeywordTB.Text;
            String inhaltText = contentTB.Text;

            try
            {
            adapter.InsertCommand = new SqlCommand(sql, sqlCon);
            sqlCon.Open();
            adapter.InsertCommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                showBtn.IsEnabled = false;
                queryContentTB.Text = "Datenbank nicht erreichbar!";
            }

            sqlCom.Dispose();
            sqlCon.Close();
            ClearTB();
            confirmLbl.Content = "Daten wurden gespeichert";
            await Task.Delay(3000);
            confirmLbl.Content = "";

        }

        private void nextBtn_Click(object sender, RoutedEventArgs e)
        {
            labelCount = 0;
            countNextClicks++;

            //reset values after each "next" click
            nextBtn.Content = "Nächste";
            confirmLblQuest.Content = "";
            queryContentTB.Text = "";
            showBtn.IsEnabled = true;
            yesRbtn.IsChecked = false;
            noRbtn.IsChecked = false;
            yesRbtn.Visibility = Visibility.Hidden;
            noRbtn.Visibility = Visibility.Hidden;

            getRowCount();
            setRandomLabels(labelCount); 
            questionsAskedCount++;      

            //next button doesn't work until one radio button is checked
           if (yesRbtn.IsChecked == false && noRbtn.IsChecked == false)
            {
                nextBtn.IsEnabled = false;
            }
        }

        private void deleteBtn_Click(object sender, RoutedEventArgs e)
        {
            ClearTB();
        }

        void ClearTB()
        {
            //fachTB.Text = "";
            subjectTB.Clear();
            //stichwortTB.Text = "";
            queryKeywordTB.Clear();
            //inhaltTB.Text = "";
            contentTB.Clear();
            confirmLbl.Content = "";
        }

        public int randomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public int getRowCount()
        {
            //SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlConnection sqlCon = ServerConnection.GetDBConnection();
            String sql = "Select * from StudyAppItem";

            try
            {
            sqlCon.Open();
            SqlCommand sqlCom = new SqlCommand(sql, sqlCon);
            SqlDataReader reader = sqlCom.ExecuteReader();

            while (reader.Read())
            {
                labelCount++;
            }
            reader.Close();
            sqlCom.Dispose();
            sqlCon.Close();
            }
            catch (Exception)
            {
                showBtn.IsEnabled = false;
                queryContentTB.Text = "Datenbank nicht erreichbar!";
            }
            return 0;
        }

        public void setRandomLabels(int count)
        {
            //SqlConnection sqlCon = new SqlConnection(connectionString);
            SqlConnection sqlCon = ServerConnection.GetDBConnection();

            //Random Number between beginning and end of table
            int randomInt = randomNumber(0, count);
            string randomIntString = randomInt.ToString();

            String sql = "Select item_subject, item_name, item_content from StudyAppItem where item_id =" + randomIntString;
            SqlCommand sqlCom = new SqlCommand(sql, sqlCon);
            try
            {
            sqlCon.Open();
            SqlDataReader reader = sqlCom.ExecuteReader();

            while (reader.Read())
            {
                querySubjectLbl.Content = reader["item_subject"].ToString();
                queryKeywordLbl.Content = reader["item_name"].ToString();
                //save content for later use when 'Lösung' is clicked
                contentLbl = reader["item_content"].ToString();
            }
            reader.Close();
            sqlCom.Dispose();
            sqlCon.Close();
            }
            catch (Exception)
            {
                showBtn.IsEnabled = false;
                queryContentTB.Text = "Datenbank nicht erreichbar!";
            }
            return;
        }

        private void solutionBtn_Click(object sender, RoutedEventArgs e)
        {
            //Show radio buttons and question after first click on "next"
            confirmLblQuest.Content = "Richtig gelöst?";
            yesRbtn.Visibility = Visibility.Visible;
            noRbtn.Visibility = Visibility.Visible;
            yesRbtn.IsEnabled = true;
            noRbtn.IsEnabled = true;
            //pass value from Datareader
            queryContentTB.Text = contentLbl;

        }

        private void yesRbtn_Click(object sender, RoutedEventArgs e)
        {
            //disable second radiobutton/ only one time choosing per question, enabling "next" button
            correctAnswersCount++;
            setPercentage();
            yesRbtn.IsEnabled = false;
            noRbtn.IsEnabled = false;
            nextBtn.IsEnabled = true;
        }

        private void noRbtn_Click(object sender, RoutedEventArgs e)
        {
            setPercentage();
            yesRbtn.IsEnabled = false;
            noRbtn.IsEnabled = false;
            nextBtn.IsEnabled = true;

        }

        //calculate percentage of right answers
        public void setPercentage()
        {
            double correctPerc = (correctAnswersCount * 100) / questionsAskedCount;
            pointsPercLbl.Content = string.Format("{0:0.00} %", correctPerc);
        }

        private void stopBtn_Click(object sender, RoutedEventArgs e)
        {
            countNextClicks = 0;
            questionsAskedCount = 0;
            correctAnswersCount = 0;
            pointsPercLbl.Content = 0;

            nextBtn.Content = "Start";
            nextBtn.IsEnabled = true;
            confirmLblQuest.Content = "";
            yesRbtn.Visibility = Visibility.Hidden;
            noRbtn.Visibility = Visibility.Hidden;
            yesRbtn.IsEnabled = false;
            noRbtn.IsEnabled = false;
        }
    }
}
